# Kohenoor Token (KEN)

This repository contains the Solidity smart contract for **Kohenoor (KEN)**.

## Contract Summary

- Token name: Kohenoor
- Token symbol: KEN
- Standard: ERC20
- Solidity version: ^0.8.20
- Total supply: 101,966 KEN
- Initial receiver and owner: `0x47865542D29d3a93FEC6a55F145c89E6846Bf1A0`
- Ownership model: OpenZeppelin `Ownable2Step`
- Supply model: Fixed supply minted once at deployment
- No mint after deployment
- No burn function
- No pause function
- No tax logic
- No rebasing logic
- Website metadata can be updated only through a 1 day timelock unless locked forever
- ETH transfers are rejected
- Rescue functions are included for accidental ERC20 or ETH recovery, excluding KEN itself

## Dependencies

This contract uses OpenZeppelin Contracts v5:

```bash
npm install @openzeppelin/contracts
```

## File Structure

```text
contracts/Kohenoor.sol
README.md
```

## Notes

The active constructor uses OpenZeppelin Contracts v5 syntax:

```solidity
constructor() ERC20("Kohenoor", "KEN") Ownable(SAFE_WALLET)
```

If using an older OpenZeppelin version, update dependencies or adjust the ownership constructor accordingly.
